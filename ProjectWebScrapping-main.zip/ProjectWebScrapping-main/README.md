# ProjectWebScrapping
Program Sederhana Scrapping Website dengan JSON

BMKG web content scraper, mengambil konten cuaca dan gempa dan menampilkan data dalam bentuk JSON

## Getting Started

### Requirements
* **Python 3.5+**
* **NumPy (`$ pip install numpy`)**
* **Pandas (`$ pip install pandas`)**
* **requests (`$ pip install requests`)**
* **BeautifulSoup4 (`$ pip install beautifulsoup4`)**
* **MatplotLib (`$ pip install matplotlib`)**

## Authors
Ogie Rizki
